<?php $__env->startSection('title', 'Login'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Login-->
    <div class="d-flex col-lg-4 align-items-center auth-bg px-2 p-lg-5">
        <div class="col-12 col-sm-8 col-md-6 col-lg-12 px-xl-2 mx-auto">
            
            <h2 class="card-title fw-bold mb-1">
                <img src="<?php echo e(asset('')); ?>public/sippadu.png" alt="">
            </h2>
            <p class="card-text mb-2"><?php echo e(__('Masuk')); ?> <?php echo e(config('app.name_2')); ?></p>
            <form class="auth-login-form mt-2" action="<?php echo e(route('login')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="mb-1">
                    <label class="form-label" for="username"><?php echo e(__('Nama pengguna')); ?></label>
                    <input class="form-control" id="username" type="text" name="username" placeholder="sippadu"
                        aria-describedby="username" autofocus="" tabindex="1" value="<?php echo e(old('username')); ?>" />
                    <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="mb-1">
                    <div class="d-flex justify-content-between">
                        <label class="form-label" for="login-password"><?php echo e(__('Password')); ?></label>
                        <?php if(Route::has('password.request')): ?>
                            <a href="<?php echo e(route('password.request')); ?>">
                                <small><?php echo e(__('Lupa Password')); ?></small>
                            </a>
                        <?php endif; ?>
                    </div>
                    <div class="input-group input-group-merge form-password-toggle">
                        <input class="form-control form-control-merge" id="password" type="password" name="password"
                            placeholder="············" aria-describedby="password" tabindex="2" />
                        <span class="input-group-text cursor-pointer">
                            <i data-feather="eye"></i>
                        </span>
                    </div>
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="mb-1">
                    <div class="form-check">
                        <input name="remember" class="form-check-input" id="remember" type="checkbox" tabindex="3"
                            <?php echo e(old('remember') ? 'checked' : ''); ?> />
                        <label class="form-check-label" for="remember"> <?php echo e(__('Ingat Saya')); ?></label>
                    </div>
                </div>
                <button class="btn btn-primary w-100" tabindex="4"><?php echo e(__('Masuk')); ?></button>
            </form>
            <?php if(Route::has('register')): ?>
                <p class="text-center mt-2">
                    <span><?php echo e(__('Belum punya akun')); ?>?</span>
                    <a href="<?php echo e(route('register')); ?>">
                        <span>&nbsp;<?php echo e(__('Daftar')); ?></span>
                    </a>
                </p>
            <?php endif; ?>
        </div>
    </div>
    <!-- /Login-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sippadu\resources\views/auth/login.blade.php ENDPATH**/ ?>