<?php $__env->startSection('title', __('Edit Laporan')); ?>

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper container-xxl p-0">
        <div class="content-header row">
            <div class="content-header-left col-md-9 col-12 mb-2">
                <div class="row breadcrumbs-top">
                    <div class="col-12">
                        <h2 class="content-header-title float-start mb-0"><?php echo e(__('Laporan')); ?></h2>
                        <div class="breadcrumb-wrapper">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>"><?php echo e(__('Home')); ?></a>
                                </li>
                                <li class="breadcrumb-item"><a
                                        href="<?php echo e(route('laporan.index')); ?>"><?php echo e(__('Laporan')); ?></a>
                                </li>
                                <li class="breadcrumb-item active">
                                    <?php echo e(__('Edit')); ?>

                                </li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="content-body">
            <section id="basic-vertical-layouts">
                <div class="card">
                    <div class="card-header">
                        <div class="card-title">
                            <h4><?php echo e(__('Form Edit Laporan')); ?></h4>
                            <small class="text-primary"><?php echo e(__('Lengkapi data dibawah dengan benar!')); ?></small>
                        </div>
                    </div>
                    <div class="card-body">
                        <form class="form form-vertical" id="form-laporan"
                            action="<?php echo e(route('laporan.update', $laporan->id)); ?>" method="POST"
                            enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>
                            <div class="row">
                                
                                <div class="col-12">
                                    <div class="mb-1">
                                        <div class="divider divider-start">
                                            <div class="divider-text"><?php echo e(__('Kegiatan :')); ?></div>
                                        </div>
                                        <div class="row">
                                            <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
                                                <div class="col-12">
                                                    <div class="mb-1 row">
                                                        <div class="col-sm-3">
                                                            <label class="col-form-label"
                                                                for="id_bidang"><?php echo e(__('Bidang')); ?></label>
                                                        </div>
                                                        <div class="col-sm-9">
                                                            <select class="select2 form-select" id="id_bidang" name="id_bidang">
                                                                <option value=""></option>
                                                                <?php $__currentLoopData = dataBidang(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($row->id); ?>"
                                                                        <?php echo e($laporan->id_bidang == $row->id ? 'selected' : ''); ?>>
                                                                        <?php echo e($row->nama_bidang); ?>

                                                                    </option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                            <div class="col-12">
                                                <div class="mb-1 row">
                                                    <div class="col-sm-3">
                                                        <label class="col-form-label"
                                                            for="judul_kegiatan"><?php echo e(__('Judul Kegiatan')); ?></label>
                                                    </div>
                                                    <div class="col-sm-9">
                                                        <input type="text" id="judul_kegiatan" class="form-control"
                                                            name="judul_kegiatan"
                                                            value="<?php echo e($laporan->judul_kegiatan); ?>" />
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <div class="mb-1 row">
                                                    <div class="col-sm-3">
                                                        <label class="col-form-label"
                                                            for="tgl_kegiatan"><?php echo e(__('Tanggal Kegiatan')); ?></label>
                                                    </div>
                                                    <div class="col-sm-9">
                                                        <input type="date" id="tgl_kegiatan" class="form-control"
                                                            name="tgl_kegiatan" value="<?php echo e($laporan->tgl_kegiatan); ?>" />
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <div class="mb-1 row">
                                                    <div class="col-sm-3">
                                                        <label class="col-form-label"
                                                            for="jam_pelaporan"><?php echo e(__('Jam Pelaporan')); ?></label>
                                                    </div>
                                                    <div class="col-sm-9">
                                                        <input type="time" id="jam_pelaporan" class="form-control"
                                                            name="jam_pelaporan" value="<?php echo e($laporan->jam_pelaporan); ?>" />
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <div class="mb-1 row">
                                                    <div class="col-sm-3">
                                                        <label class="col-form-label"
                                                            for="id_jenis_kegiatan"><?php echo e(__('Jenis Kegiatan')); ?></label>
                                                    </div>
                                                    <div class="col-sm-9">
                                                        <select class="select2 form-select" id="id_jenis_kegiatan"
                                                            name="id_jenis_kegiatan">
                                                            <option value=""></option>
                                                            <?php $__currentLoopData = dataJenisKegiatan(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($row->id); ?>"
                                                                    <?php echo e($laporan->id_jenis_kegiatan == $row->id ? 'selected' : ''); ?>>
                                                                    <?php echo e($row->nama_jenis_kegiatan); ?>

                                                                </option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-12">
                                    <div class="mb-1">
                                        <div class="divider divider-start">
                                            <div class="divider-text"><?php echo e(__('Jumlah Personil Yang Terlibat :')); ?></div>
                                        </div>
                                        <div class="row">
                                            <div class="col-12">
                                                <div class="mb-1 row">
                                                    <div class="col-sm-3">
                                                        <label class="col-form-label"
                                                            for="polisi"><?php echo e(__('Polisi')); ?></label>
                                                    </div>
                                                    <div class="col-sm-9">
                                                        <input type="number" id="polisi" class="form-control"
                                                            name="polisi" value="<?php echo e($laporan->polisi); ?>" />
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <div class="mb-1 row">
                                                    <div class="col-sm-3">
                                                        <label class="col-form-label"
                                                            for="tni"><?php echo e(__('TNI')); ?></label>
                                                    </div>
                                                    <div class="col-sm-9">
                                                        <input type="number" id="tni" class="form-control"
                                                            name="tni" value="<?php echo e($laporan->tni); ?>" />
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <div class="mb-1 row">
                                                    <div class="col-sm-3">
                                                        <label class="col-form-label"
                                                            for="pol_pp_prov"><?php echo e(__('Pol PP Provinsi')); ?></label>
                                                    </div>
                                                    <div class="col-sm-9">
                                                        <input type="number" id="pol_pp_prov" class="form-control"
                                                            name="pol_pp_prov" value="<?php echo e($laporan->pol_pp_prov); ?>" />
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <div class="mb-1 row">
                                                    <div class="col-sm-3">
                                                        <label class="col-form-label"
                                                            for="pol_pp_kabkot"><?php echo e(__('Pol PP Kab/Kota')); ?></label>
                                                    </div>
                                                    <div class="col-sm-9">
                                                        <input type="number" id="pol_pp_kabkot" class="form-control"
                                                            name="pol_pp_kabkot" value="<?php echo e($laporan->pol_pp_kabkot); ?>" />
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <div class="mb-1 row">
                                                    <div class="col-sm-3">
                                                        <label class="col-form-label"
                                                            for="perangkat_daerah_lainnya"><?php echo e(__('Perangkat Daerah Lainnya  ')); ?></label>
                                                    </div>
                                                    <div class="col-sm-9">
                                                        <input type="number" id="perangkat_daerah_lainnya"
                                                            class="form-control" name="perangkat_daerah_lainnya"
                                                            value="<?php echo e($laporan->perangkat_daerah_lainnya); ?>" />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-12">
                                    <div class="mb-1">
                                        <div class="divider divider-start">
                                            <div class="divider-text"><?php echo e(__('Lokasi Kegiatan :')); ?></div>
                                        </div>
                                        <div class="row">
                                            <div class="col-12">
                                                <div class="mb-1 row">
                                                    <div class="col-sm-3">
                                                        <label class="col-form-label"
                                                            for="lokasi"><?php echo e(__('Lokasi')); ?></label>
                                                    </div>
                                                    <div class="col-sm-9">
                                                        <input type="text" id="lokasi" class="form-control"
                                                            name="lokasi" value="<?php echo e($laporan->lokasi); ?>"
                                                            placeholder="Cari Lokasi" />
                                                        
                                                        <div id="map"
                                                            style=" height: 50vh;width: 100%;margin-top: 10px;">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <div class="mb-1 row">
                                                    <div class="col-sm-3">
                                                        <label class="col-form-label"
                                                            for="latitude"><?php echo e(__('Latitude')); ?></label>
                                                    </div>
                                                    <div class="col-sm-9">
                                                        <input type="text" id="latitude" class="form-control"
                                                            name="latitude" value="<?php echo e($laporan->latitude); ?>"
                                                            readonly />
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <div class="mb-1 row">
                                                    <div class="col-sm-3">
                                                        <label class="col-form-label"
                                                            for="longitude"><?php echo e(__('Longitude')); ?></label>
                                                    </div>
                                                    <div class="col-sm-9">
                                                        <input type="text" id="longitude" class="form-control"
                                                            name="longitude" value="<?php echo e($laporan->longitude); ?>"
                                                            readonly />
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <div class="mb-1 row">
                                                    <div class="col-sm-3">
                                                        <label class="col-form-label"
                                                            for="alamat"><?php echo e(__('Alamat Lengkap')); ?></label>
                                                    </div>
                                                    <div class="col-sm-9">
                                                        <input type="text" id="alamat" class="form-control"
                                                            name="alamat" value="<?php echo e($laporan->alamat); ?>" />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-12">
                                    <div class="mb-1">
                                        <div class="divider divider-start">
                                            <div class="divider-text"><?php echo e(__('Pelanggaran :')); ?></div>
                                        </div>
                                        <div class="row">
                                            <div class="col-12">
                                                <div class="mb-1 row">
                                                    <div class="col-sm-3">
                                                        <label class="col-form-label"
                                                            for="id_jenis_pelanggaran"><?php echo e(__('Jenis Pelanggaran')); ?></label>
                                                    </div>
                                                    <div class="col-sm-9">
                                                        <select class="select2 form-select" id="id_jenis_pelanggaran"
                                                            name="id_jenis_pelanggaran">
                                                            <option value=""></option>
                                                            <?php $__currentLoopData = dataJenisPelanggaran(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($row->id); ?>"
                                                                    <?php echo e($laporan->laporanPelanggaran->id_jenis_pelanggaran == $row->id ? 'selected' : ''); ?>>
                                                                    <?php echo e($row->nama_jenis_pelanggaran); ?>

                                                                </option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <div class="mb-1 row">
                                                    <div class="col-sm-3">
                                                        <label class="col-form-label"
                                                            for="id_sangsi"><?php echo e(__('Sangsi')); ?></label>
                                                    </div>
                                                    <div class="col-sm-9">
                                                        <select class="select2 form-select" id="id_sangsi"
                                                            name="id_sangsi">
                                                            <option value=""></option>
                                                            <?php $__currentLoopData = dataSangsi(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($row->id); ?>"
                                                                    <?php echo e($laporan->laporanPelanggaran->id_sangsi == $row->id ? 'selected' : ''); ?>>
                                                                    <?php echo e($row->nama_sangsi); ?>

                                                                </option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <div class="mb-1 row">
                                                    <div class="col-sm-3">
                                                        <label class="col-form-label"
                                                            for="detail"><?php echo e(__('Detail')); ?></label>
                                                    </div>
                                                    <div class="col-sm-9">
                                                        <input type="text" id="detail" class="form-control"
                                                            name="detail"
                                                            value="<?php echo e($laporan->laporanPelanggaran->detail); ?>" />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-12">
                                    <div class="mb-1">
                                        <div class="divider divider-start">
                                            <div class="divider-text"><?php echo e(__('Dokumentasi :')); ?></div>
                                        </div>
                                        <div class="row">
                                            <div class="col-12">
                                                <div class="mb-1 row">
                                                    <div class="col-sm-3">
                                                        <label class="col-form-label"
                                                            for="dokumen"><?php echo e(__('Foto')); ?></label>
                                                    </div>
                                                    <div class="col-sm-9">
                                                        <div class="border rounded p-2">
                                                            <div class="d-flex flex-column flex-md-row">
                                                                <img src="<?php echo e(asset('')); ?>public/dokumentasi/<?php echo e($laporan->laporanDokumentasi->dokumen); ?>"
                                                                    id="dokumen-image" class="rounded me-2 mb-1 mb-md-0"
                                                                    width="170" height="110"
                                                                    alt="<?php echo e(__('Dokumentasi')); ?>" />
                                                                <div class="featured-info">
                                                                    <small class="text-muted">
                                                                        Max image size 2mb.
                                                                    </small>
                                                                    <p class="my-50">
                                                                        <span
                                                                            id="dokumen-text"><?php echo e($laporan->laporanDokumentasi->dokumen); ?></span>
                                                                    </p>
                                                                    <div class="d-inline-block">
                                                                        <input class="form-control" type="file"
                                                                            id="dokumen" accept="image/*"
                                                                            name="dokumen" />
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-12">
                                    <div class="mb-1">
                                        <div class="divider divider-start">
                                            <div class="divider-text"><?php echo e(__('Lainnya :')); ?></div>
                                        </div>
                                        <div class="row">
                                            <div class="col-12">
                                                <div class="mb-1 row">
                                                    <div class="col-sm-3">
                                                        <label class="col-form-label"
                                                            for="keterangan_lainnya"><?php echo e(__('Keterangan')); ?></label>
                                                    </div>
                                                    <div class="col-sm-9">
                                                        <textarea name="keterangan_lainnya" class="form-control" id="keterangan_lainnya" cols="30" rows="3"><?php echo e($laporan->keterangan_lainnya); ?></textarea>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12 mt-2">
                                    <button type="submit" class="btn btn-primary me-1"
                                        id="btn-save"><?php echo e(__('Simpan')); ?></button>
                                    <a href="<?php echo e(route('laporan.index')); ?>"
                                        class="btn btn-outline-secondary"><?php echo e(__('Kembali')); ?></a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </section>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('')); ?>public/assets/js/laporan/edit/maps.js"></script>
    <script src="<?php echo e(asset('')); ?>public/assets/js/laporan/edit/update.js"></script>
    <script>
        $(document).ready(function() {
            // Select2
            $('.select2').each(function() {
                var $this = $(this);
                $this.wrap('<div class="position-relative"></div>');
                $this.select2({
                    dropdownAutoWidth: true,
                    width: '100%',
                    dropdownParent: $this.parent()
                });
            });

            // Dokumen
            var dokumenImage = $('#dokumen-image');
            var dokumenText = document.getElementById('dokumen-text');
            var dokumenInput = $('#dokumen');
            // Change dokumen image
            if (dokumenInput.length) {
                $(dokumenInput).on('change', function(e) {
                    var reader = new FileReader(),
                        files = e.target.files;
                    reader.onload = function() {
                        if (dokumenImage.length) {
                            dokumenImage.attr('src', reader.result);
                        }
                    };
                    reader.readAsDataURL(files[0]);
                    dokumenText.innerHTML = dokumenInput.val();
                });
            }
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sippadu\resources\views/laporan/edit.blade.php ENDPATH**/ ?>