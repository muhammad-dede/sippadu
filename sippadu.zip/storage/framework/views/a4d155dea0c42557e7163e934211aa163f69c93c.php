<?php $__env->startSection('title', __('Sangsi')); ?>

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper container-xxl p-0">
        <div class="content-header row">
            <div class="content-header-left col-md-9 col-12 mb-2">
                <div class="row breadcrumbs-top">
                    <div class="col-12">
                        <h2 class="content-header-title float-start mb-0"><?php echo e(__('Sangsi')); ?></h2>
                        <div class="breadcrumb-wrapper">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>"><?php echo e(__('Home')); ?></a>
                                </li>
                                <li class="breadcrumb-item active">
                                    <?php echo e(__('Sangsi')); ?>

                                </li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
            <div class="content-header-right text-md-end col-md-3 col-12">
                <div class="mb-1 breadcrumb-right">
                    <a href="<?php echo e(route('sangsi.create')); ?>" class="dt-button create-new btn btn-primary" id="btn-tambah">
                        <span>
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                                fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                stroke-linejoin="round" class="feather feather-plus me-50 font-small-4">
                                <line x1="12" y1="5" x2="12" y2="19">
                                </line>
                                <line x1="5" y1="12" x2="19" y2="12">
                                </line>
                            </svg>
                            <?php echo e(__('Tambah')); ?>

                        </span>
                    </a>
                </div>
            </div>
        </div>
        <div class="content-body">
            <section id="basic-datatable">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table" id="datatable">
                                        <thead>
                                            <tr>
                                                <th><?php echo e(__('No')); ?></th>
                                                <th><?php echo e(__('Nama Sangsi')); ?></th>
                                                <th><?php echo e(__('Status')); ?></th>
                                                <th><?php echo e(__('Opsi')); ?></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($loop->iteration); ?></td>
                                                    <td><?php echo e($row->nama_sangsi); ?></td>
                                                    <td>
                                                        <form action="<?php echo e(route('sangsi.destroy', $row->id)); ?>"
                                                            method="POST" id="form-status">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('delete'); ?>
                                                            <button type="submit"
                                                                class="btn btn-sm <?php echo e($row->active ? 'btn-success' : 'btn-danger'); ?> btn-status"
                                                                id="btn-status">
                                                                <?php echo e($row->active ? __('Aktif') : __('Tidak Aktif')); ?>

                                                            </button>
                                                        </form>
                                                    </td>
                                                    <td>
                                                        <a href="<?php echo e(route('sangsi.edit', $row->id)); ?>"
                                                            class="btn btn-sm btn-secondary">
                                                            <?php echo e(__('Edit')); ?>

                                                        </a>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>sive
                    </div>
                </div>
            </section>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        $(document).ready(function() {
            $('#datatable').DataTable();

            <?php if(Session::has('success')): ?>
                Swal.fire({
                    icon: 'success',
                    title: "<?php echo e(Session::get('success')); ?>",
                })
            <?php endif; ?>
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sippadu\resources\views/sangsi/index.blade.php ENDPATH**/ ?>