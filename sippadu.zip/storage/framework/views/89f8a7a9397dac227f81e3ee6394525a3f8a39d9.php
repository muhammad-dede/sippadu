<?php $__env->startSection('title', __('Tambah Jenis Pelanggaran')); ?>

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper container-xxl p-0">
        <div class="content-header row">
            <div class="content-header-left col-md-9 col-12 mb-2">
                <div class="row breadcrumbs-top">
                    <div class="col-12">
                        <h2 class="content-header-title float-start mb-0"><?php echo e(__('Jenis Pelanggaran')); ?></h2>
                        <div class="breadcrumb-wrapper">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>"><?php echo e(__('Home')); ?></a>
                                </li>
                                <li class="breadcrumb-item"><a
                                        href="<?php echo e(route('jenis-pelanggaran.index')); ?>"><?php echo e(__('Jenis Pelanggaran')); ?></a>
                                </li>
                                <li class="breadcrumb-item active">
                                    <?php echo e(__('Tambah')); ?>

                                </li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="content-body">
            <section id="basic-vertical-layouts">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title"><?php echo e(__('Form Tambah Jenis Pelanggaran')); ?></h4>
                    </div>
                    <div class="card-body">
                        <form class="form form-vertical" action="<?php echo e(route('jenis-pelanggaran.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-12">
                                    <div class="mb-1">
                                        <label class="form-label"
                                            for="nama_jenis_pelanggaran"><?php echo e(__('Nama Jenis Pelanggaran')); ?></label>
                                        <input type="text" id="nama_jenis_pelanggaran"
                                            class="form-control <?php $__errorArgs = ['nama_jenis_pelanggaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="nama_jenis_pelanggaran" value="<?php echo e(old('nama_jenis_pelanggaran')); ?>" />
                                        <?php $__errorArgs = ['nama_jenis_pelanggaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-12 mt-2">
                                    <button type="submit" class="btn btn-primary me-1"><?php echo e(__('Simpan')); ?></button>
                                    <a href="<?php echo e(route('jenis-pelanggaran.index')); ?>"
                                        class="btn btn-outline-secondary"><?php echo e(__('Kembali')); ?></a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </section>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sippadu\resources\views/jenis-pelanggaran/create.blade.php ENDPATH**/ ?>