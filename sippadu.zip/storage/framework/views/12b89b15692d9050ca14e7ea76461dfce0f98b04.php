<?php $__env->startSection('title', __('Detail Laporan')); ?>

<?php $__env->startPush('css'); ?>
    <style>
        table td,
        table td * {
            vertical-align: top;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper container-xxl p-0">
        <div class="content-header row">
            <div class="content-header-left col-md-9 col-12 mb-2">
                <div class="row breadcrumbs-top">
                    <div class="col-12">
                        <h2 class="content-header-title float-start mb-0"><?php echo e(__('Laporan')); ?></h2>
                        <div class="breadcrumb-wrapper">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>"><?php echo e(__('Home')); ?></a>
                                </li>
                                <li class="breadcrumb-item"><a
                                        href="<?php echo e(route('laporan.index')); ?>"><?php echo e(__('Laporan')); ?></a>
                                </li>
                                <li class="breadcrumb-item active">
                                    <?php echo e(__('Detail')); ?>

                                </li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="content-body">
            <div class="blog-detail-wrapper">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            
                            <div class="card-body">
                                <h4 class="mb-75"><?php echo e(__('Laporan Kegiatan')); ?>:</h4>
                                <table class="p-0 mb-2">
                                    <tbody>
                                        <tr>
                                            <td><?php echo e(__('Judul Kegiatan')); ?></td>
                                            <td>&nbsp;:&nbsp;</td>
                                            <td>
                                                <strong><?php echo e($laporan->judul_kegiatan); ?></strong>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td><?php echo e(__('Bidang')); ?></td>
                                            <td>&nbsp;:&nbsp;</td>
                                            <td><?php echo e($laporan->bidang ? $laporan->bidang->nama_bidang : ''); ?></td>
                                        </tr>
                                        <tr>
                                            <td><?php echo e(__('Tanggal')); ?></td>
                                            <td>&nbsp;:&nbsp;</td>
                                            <td><?php echo e(\Carbon\Carbon::parse($laporan->tgl_kegiatan)->isoFormat('D MMMM Y')); ?>

                                            </td>
                                        </tr>
                                        <tr>
                                            <td><?php echo e(__('Jam')); ?></td>
                                            <td>&nbsp;:&nbsp;</td>
                                            <td><?php echo e(\Carbon\Carbon::parse($laporan->jam_pelaporan)->isoFormat('HH:MM')); ?>

                                            </td>
                                        </tr>
                                        <tr>
                                            <td><?php echo e(__('Jenis Kegiatan')); ?></td>
                                            <td>&nbsp;:&nbsp;</td>
                                            <td><?php echo e($laporan->jenisKegiatan ? $laporan->jenisKegiatan->nama_jenis_kegiatan : ''); ?>

                                            </td>
                                        </tr>
                                        <tr>
                                            <td><?php echo e(__('Keterangan')); ?></td>
                                            <td>&nbsp;:&nbsp;</td>
                                            <td><?php echo e($laporan->keterangan_lainnya); ?>

                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                                <h4 class="mb-75"><?php echo e(__('Jumlah Personil Yang Terlibat')); ?>:</h4>
                                <table class="p-0 mb-2">
                                    <tbody>
                                        <tr>
                                            <td><?php echo e(__('Polisi')); ?></td>
                                            <td>&nbsp;:&nbsp;</td>
                                            <td><?php echo e($laporan->polisi); ?></td>
                                        </tr>
                                        <tr>
                                            <td><?php echo e(__('TNI')); ?></td>
                                            <td>&nbsp;:&nbsp;</td>
                                            <td><?php echo e($laporan->tni); ?></td>
                                        </tr>
                                        <tr>
                                            <td><?php echo e(__('Pol PP Kab/Kota')); ?></td>
                                            <td>&nbsp;:&nbsp;</td>
                                            <td><?php echo e($laporan->pol_pp); ?></td>
                                        </tr>
                                        <tr>
                                            <td><?php echo e(__('Perangkat Daerah Lainnya')); ?></td>
                                            <td>&nbsp;:&nbsp;</td>
                                            <td><?php echo e($laporan->perangkat_daerah_lainnya); ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                                <h4 class="mb-75"><?php echo e(__('Lokasi')); ?>:</h4>
                                <input type="hidden" id="latitude" value="<?php echo e($laporan->latitude); ?>">
                                <input type="hidden" id="longitude" value="<?php echo e($laporan->longitude); ?>">
                                <div id="map" style=" height: 50vh;width: 100%;margin-top: 10px;">
                                </div>
                                <table class="p-0 mb-2 mt-1">
                                    <tbody>
                                        <tr>
                                            <td><?php echo e(__('Alamat Lengkap')); ?></td>
                                            <td>&nbsp;:&nbsp;</td>
                                            <td><?php echo e($laporan->alamat); ?></td>
                                        </tr>
                                        <tr>
                                            <td><?php echo e(__('Lokasi')); ?></td>
                                            <td>&nbsp;:&nbsp;</td>
                                            <td><?php echo e($laporan->lokasi); ?></td>
                                        </tr>
                                        <tr>
                                            <td><?php echo e(__('Latitude')); ?></td>
                                            <td>&nbsp;:&nbsp;</td>
                                            <td><?php echo e($laporan->latitude); ?></td>
                                        </tr>
                                        <tr>
                                            <td><?php echo e(__('Longitude')); ?></td>
                                            <td>&nbsp;:&nbsp;</td>
                                            <td><?php echo e($laporan->longitude); ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                                <?php if($laporan->laporanPelanggaran): ?>
                                    <h4 class="mb-75"><?php echo e(__('Pelanggaran')); ?>:</h4>
                                    <table class="p-0 mb-2">
                                        <tbody>
                                            <tr>
                                                <td><?php echo e(__('Jenis Pelanggaran')); ?></td>
                                                <td>&nbsp;:&nbsp;</td>
                                                <td>
                                                    <?php echo e($laporan->laporanPelanggaran ? ($laporan->laporanPelanggaran->jenisPelanggaran ? $laporan->laporanPelanggaran->jenisPelanggaran->nama_jenis_pelanggaran : '') : ''); ?>

                                                </td>
                                            </tr>
                                            <tr>
                                                <td><?php echo e(__('Sangsi')); ?></td>
                                                <td>&nbsp;:&nbsp;</td>
                                                <td>
                                                    <?php echo e($laporan->laporanPelanggaran ? ($laporan->laporanPelanggaran->sangsi ? $laporan->laporanPelanggaran->sangsi->nama_sangsi : '') : ''); ?>

                                                </td>
                                            </tr>
                                            <tr>
                                                <td><?php echo e(__('Detail')); ?></td>
                                                <td>&nbsp;:&nbsp;</td>
                                                <td>
                                                    <?php echo e($laporan->laporanPelanggaran ? $laporan->laporanPelanggaran->detail : ''); ?>

                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                <?php endif; ?>
                                <?php if($laporan->laporanDokumentasi): ?>
                                    <h4 class="mb-75"><?php echo e(__('Dokumentasi')); ?>:</h4>
                                    <table class="p-0 mb-2">
                                        <tbody>
                                            <tr>
                                                <td>
                                                    <?php if($laporan->laporanDokumentasi->dokumen): ?>
                                                        <a href="<?php echo e(asset('')); ?>public/dokumentasi/<?php echo e($laporan->laporanDokumentasi->dokumen); ?>"
                                                            target="_blank">
                                                            <img src="<?php echo e(asset('')); ?>public/dokumentasi/<?php echo e($laporan->laporanDokumentasi->dokumen); ?>"
                                                                alt="dokumen" class="rounded me-2 mb-1 mb-md-0"
                                                                width="170" height="110">
                                                        </a>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                <?php endif; ?>
                                <hr class="my-2" />
                                <div class="d-flex align-items-center justify-content-between">
                                    <div class="d-flex align-items-center">
                                        <div class="d-flex align-items-center me-1">
                                            <a href="<?php echo e(route('laporan.edit', $laporan->id)); ?>" class="btn btn-warning">
                                                <?php echo e(__('Edit')); ?>

                                            </a>
                                        </div>
                                        <div class="d-flex align-items-center">
                                            <a href="<?php echo e(route('laporan.index')); ?>" class="btn btn-outline-secondary">
                                                <?php echo e(__('Kembali')); ?>

                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('')); ?>public/assets/js/laporan/show/maps.js"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sippadu\resources\views/laporan/show.blade.php ENDPATH**/ ?>