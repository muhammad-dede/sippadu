<div class="main-menu menu-fixed menu-light menu-accordion menu-shadow" data-scroll-to-active="true">
    <div class="navbar-header">
        <ul class="nav navbar-nav flex-row">
            <li class="nav-item me-auto"><a class="navbar-brand" href="<?php echo e(route('home')); ?>">
                    <img src="<?php echo e(asset('')); ?>public/sippadu.png" alt="" class="w-75">
                    
                </a>
            </li>
            <li class="nav-item nav-toggle">
                <a class="nav-link modern-nav-toggle pe-0" data-bs-toggle="collapse">
                    <i class="d-block d-xl-none text-primary toggle-icon font-medium-4" data-feather="x"></i>
                    <i class="d-none d-xl-block collapse-toggle-icon font-medium-4 text-primary" data-feather="disc"
                        data-ticon="disc"></i>
                </a>
            </li>
        </ul>
    </div>
    <div class="shadow-bottom"></div>
    <div class="main-menu-content pt-1">
        <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation">
            <li class="mt-2 nav-item <?php echo e(Request::is('/') || Request::is('home') ? 'active' : ''); ?>">
                <a class="d-flex align-items-center" href="<?php echo e(route('home')); ?>">
                    <i data-feather="home"></i>
                    <span class="menu-title text-truncate" data-i18n="<?php echo e(__('Beranda')); ?>">
                        <?php echo e(__('Beranda')); ?>

                    </span>
                    
                </a>
            </li>
            <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
                
                <li class=" navigation-header">
                    <span data-i18n="<?php echo e(__('Manajemen Data')); ?>"><?php echo e(__('Manajemen Data')); ?></span>
                    <i data-feather="more-horizontal"></i>
                </li>
                <li class=" nav-item">
                    <a class="d-flex align-items-center" href="#">
                        <i data-feather="layout"></i>
                        <span class="menu-title text-truncate" data-i18n="<?php echo e(__('Master Data')); ?>">
                            <?php echo e(__('Master Data')); ?>

                        </span>
                    </a>
                    <ul class="menu-content">
                        <li
                            class="<?php echo e(Request::is('bidang') || Request::is('bidang/*/edit') || Request::is('bidang/create') ? 'active' : ''); ?>">
                            <a class="d-flex align-items-center" href="<?php echo e(route('bidang.index')); ?>">
                                <i data-feather="circle"></i>
                                <span class="menu-item text-truncate" data-i18n="<?php echo e(__('Bidang')); ?>">
                                    <?php echo e(__('Bidang')); ?>

                                </span>
                            </a>
                        </li>
                        <li
                            class="<?php echo e(Request::is('jenis-kegiatan') || Request::is('jenis-kegiatan/*/edit') || Request::is('jenis-kegiatan/create') ? 'active' : ''); ?>">
                            <a class="d-flex align-items-center" href="<?php echo e(route('jenis-kegiatan.index')); ?>">
                                <i data-feather="circle"></i>
                                <span class="menu-item text-truncate" data-i18n="<?php echo e(__('Jenis Kegiatan')); ?>">
                                    <?php echo e(__('Jenis Kegiatan')); ?>

                                </span>
                            </a>
                        </li>
                        <li
                            class="<?php echo e(Request::is('jenis-pelanggaran') || Request::is('jenis-pelanggaran/*/edit') || Request::is('jenis-pelanggaran/create') ? 'active' : ''); ?>">
                            <a class="d-flex align-items-center" href="<?php echo e(route('jenis-pelanggaran.index')); ?>">
                                <i data-feather="circle"></i>
                                <span class="menu-item text-truncate" data-i18n="<?php echo e(__('Jenis Pelanggaran')); ?>">
                                    <?php echo e(__('Jenis Pelanggaran')); ?>

                                </span>
                            </a>
                        </li>
                        <li
                            class="<?php echo e(Request::is('sangsi') || Request::is('sangsi/*/edit') || Request::is('sangsi/create') ? 'active' : ''); ?>">
                            <a class="d-flex align-items-center" href="<?php echo e(route('sangsi.index')); ?>">
                                <i data-feather="circle"></i>
                                <span class="menu-item text-truncate" data-i18n="<?php echo e(__('Sangsi')); ?>">
                                    <?php echo e(__('Sangsi')); ?>

                                </span>
                            </a>
                        </li>
                    </ul>
                </li>
                <li
                    class=" nav-item <?php echo e(Request::is('user') || Request::is('user/*/edit') || Request::is('user/create') ? 'active' : ''); ?>">
                    <a class="d-flex align-items-center" href="<?php echo e(route('user.index')); ?>">
                        <i data-feather='users'></i>
                        <span class="menu-title text-truncate" data-i18n="<?php echo e(__('User')); ?>">
                            <?php echo e(__('User')); ?>

                        </span>
                    </a>
                </li>
            <?php endif; ?>
            
            <li class=" navigation-header">
                <span data-i18n="<?php echo e(__('Laporan')); ?>"><?php echo e(__('Laporan')); ?></span>
                <i data-feather="more-horizontal"></i>
            </li>
            <li class=" nav-item <?php echo e(Request::is('laporan/create') ? 'active' : ''); ?>">
                <a class="d-flex align-items-center" href="<?php echo e(route('laporan.create')); ?>">
                    <i data-feather='file-plus'></i>
                    <span class="menu-title text-truncate" data-i18n="<?php echo e(__('Buat Laporan')); ?>">
                        <?php echo e(__('Buat Laporan')); ?>

                    </span>
                </a>
            </li>
            <li
                class=" nav-item <?php echo e(Request::is('laporan') || Request::is('laporan/*/edit') || Request::is('laporan/*/show') ? 'active' : ''); ?>">
                <a class="d-flex align-items-center" href="<?php echo e(route('laporan.index')); ?>">
                    <i data-feather='book-open'></i>
                    <span class="menu-title text-truncate" data-i18n="<?php echo e(__('Data Laporan')); ?>">
                        <?php echo e(__('Data Laporan')); ?>

                    </span>
                </a>
            </li>
            
            <li class=" navigation-header">
                <span data-i18n="<?php echo e(__('Pengaturan')); ?>"><?php echo e(__('Pengaturan')); ?></span>
                <i data-feather="more-horizontal"></i>
            </li>
            <li class=" nav-item <?php echo e(Request::is('akun') ? 'active' : ''); ?>">
                <a class="d-flex align-items-center" href="<?php echo e(route('akun.index')); ?>">
                    <i data-feather='settings'></i>
                    <span class="menu-title text-truncate" data-i18n="<?php echo e(__('Akun')); ?>">
                        <?php echo e(__('Akun')); ?>

                    </span>
                </a>
            </li>
        </ul>
    </div>
</div>
<?php /**PATH C:\laragon\www\sippadu\resources\views/layouts/includes/menu.blade.php ENDPATH**/ ?>