<footer class="footer footer-static footer-light">
    <p class="clearfix mb-0"><span class="float-md-start d-block d-md-inline-block mt-25">
            COPYRIGHT &copy; <?php echo e(date('Y')); ?>

            <a class="ms-25" href="<?php echo e(url('/')); ?>" target="_blank"
                id="footer-link"><?php echo e(config('app.name')); ?></a><span class="d-none d-sm-inline-block">, All rights
                Reserved</span>
        </span>
        <span class="float-md-end d-none d-md-block"><?php echo e(config('app.name_2')); ?>

            <i data-feather="heart"></i>
        </span>
    </p>
</footer>
<?php /**PATH C:\laragon\www\sippadu\resources\views/layouts/includes/footer.blade.php ENDPATH**/ ?>