<!DOCTYPE html>
<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title><?php echo e($laporan->judul_kegiatan); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
    <style>
        .page-break {
            page-break-after: always;
        }
    </style>
</head>

<body>
    <h1 class="text-center"><?php echo e(__('Laporan Kegiatan')); ?></h1>
    <hr>
    <table class="table">
        <tbody>
            <tr>
                <td colspan="3">
                    <h4><?php echo e(__('Laporan Kegiatan')); ?>:</h4>
                </td>
            </tr>
            <tr>
                <td><?php echo e(__('Judul Kegiatan')); ?></td>
                <td>:</td>
                <td>
                    <strong><?php echo e($laporan->judul_kegiatan); ?></strong>
                </td>
            </tr>
            <tr>
                <td><?php echo e(__('Bidang')); ?></td>
                <td>:</td>
                <td><?php echo e($laporan->bidang ? $laporan->bidang->nama_bidang : ''); ?></td>
            </tr>
            <tr>
                <td><?php echo e(__('Tanggal')); ?></td>
                <td>:</td>
                <td><?php echo e(\Carbon\Carbon::parse($laporan->tgl_kegiatan)->isoFormat('D MMMM Y')); ?>

                </td>
            </tr>
            <tr>
                <td><?php echo e(__('Jam')); ?></td>
                <td>:</td>
                <td><?php echo e(\Carbon\Carbon::parse($laporan->jam_pelaporan)->isoFormat('HH:MM')); ?>

                </td>
            </tr>
            <tr>
                <td><?php echo e(__('Jenis Kegiatan')); ?></td>
                <td>:</td>
                <td><?php echo e($laporan->jenisKegiatan ? $laporan->jenisKegiatan->nama_jenis_kegiatan : ''); ?>

                </td>
            </tr>
            <tr>
                <td><?php echo e(__('Keterangan')); ?></td>
                <td>:</td>
                <td><?php echo e($laporan->keterangan_lainnya); ?>

                </td>
            </tr>
            <tr>
                <td colspan="3">
                    <h4 class="mt-4"><?php echo e(__('Jumlah Personil Yang Terlibat')); ?>:</h4>
                </td>
            </tr>
            <tr>
                <td><?php echo e(__('Pol PP Provinsi')); ?></td>
                <td>:</td>
                <td><?php echo e($laporan->pol_pp_prov); ?></td>
            </tr>
            <tr>
                <td><?php echo e(__('Pol PP Kab/Kota')); ?></td>
                <td>:</td>
                <td><?php echo e($laporan->pol_pp_kabkot); ?></td>
            </tr>
            <tr>
                <td><?php echo e(__('Polisi')); ?></td>
                <td>:</td>
                <td><?php echo e($laporan->polisi); ?></td>
            </tr>
            <tr>
                <td><?php echo e(__('TNI')); ?></td>
                <td>:</td>
                <td><?php echo e($laporan->tni); ?></td>
            </tr>
            <tr>
                <td><?php echo e(__('Perangkat Daerah Lainnya')); ?></td>
                <td>:</td>
                <td><?php echo e($laporan->perangkat_daerah_lainnya); ?></td>
            </tr>
            <tr>
                <td colspan="3">
                    <h4 class="mt-4"><?php echo e(__('Lokasi')); ?>:</h4>
                </td>
            </tr>
            <tr>
                <td><?php echo e(__('Alamat Lengkap')); ?></td>
                <td>:</td>
                <td><?php echo e($laporan->alamat); ?></td>
            </tr>
            <tr>
                <td><?php echo e(__('Lokasi')); ?></td>
                <td>:</td>
                <td><?php echo e($laporan->lokasi); ?></td>
            </tr>
            <tr>
                <td><?php echo e(__('Latitude')); ?></td>
                <td>:</td>
                <td><?php echo e($laporan->latitude); ?></td>
            </tr>
            <tr>
                <td><?php echo e(__('Longitude')); ?></td>
                <td>:</td>
                <td><?php echo e($laporan->longitude); ?></td>
            </tr>
            <?php if($laporan->laporanPelanggaran): ?>
                <tr>
                    <td colspan="3">
                        <h4 class="mt-4"><?php echo e(__('Pelanggaran')); ?>:</h4>
                    </td>
                </tr>
                <tr>
                    <td><?php echo e(__('Jenis Pelanggaran')); ?></td>
                    <td>:</td>
                    <td>
                        <?php echo e($laporan->laporanPelanggaran ? ($laporan->laporanPelanggaran->jenisPelanggaran ? $laporan->laporanPelanggaran->jenisPelanggaran->nama_jenis_pelanggaran : '') : ''); ?>

                    </td>
                </tr>
                <tr>
                    <td><?php echo e(__('Sangsi')); ?></td>
                    <td>:</td>
                    <td>
                        <?php echo e($laporan->laporanPelanggaran ? ($laporan->laporanPelanggaran->sangsi ? $laporan->laporanPelanggaran->sangsi->nama_sangsi : '') : ''); ?>

                    </td>
                </tr>
                <tr>
                    <td><?php echo e(__('Detail')); ?></td>
                    <td>:</td>
                    <td>
                        <?php echo e($laporan->laporanPelanggaran ? $laporan->laporanPelanggaran->detail : ''); ?>

                    </td>
                </tr>
            <?php endif; ?>
            <?php if($laporan->laporanDokumentasi): ?>
                <tr>
                    <td colspan="3">
                        <h4 class="mt-4"><?php echo e(__('Dokumentasi')); ?>:</h4>
                    </td>
                </tr>
                <tr>
                    <td>
                        <?php if($laporan->laporanDokumentasi->dokumen): ?>
                            <a href="<?php echo e(asset('')); ?>public/dokumentasi/<?php echo e($laporan->laporanDokumentasi->dokumen); ?>"
                                target="_blank">
                                <img src="<?php echo e(asset('')); ?>public/dokumentasi/<?php echo e($laporan->laporanDokumentasi->dokumen); ?>"
                                    alt="dokumen" class="rounded me-2 mb-1 mb-md-0" width="170" height="110">
                            </a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous">
    </script>
</body>

</html>
<?php /**PATH C:\laragon\www\sippadu\resources\views/laporan/print.blade.php ENDPATH**/ ?>